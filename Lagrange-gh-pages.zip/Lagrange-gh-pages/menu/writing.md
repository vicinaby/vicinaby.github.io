---
layout: archive
title: Writing
permalink: /writing
---
