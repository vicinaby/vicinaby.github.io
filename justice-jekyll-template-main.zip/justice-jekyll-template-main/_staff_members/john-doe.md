---
name: John Doe
image: "//placebear.com/440/440?a=.png"
credentials: LLB
phone_extension: "11"
---

With an interest in employment law, John works tirelessly to improve workplaces.