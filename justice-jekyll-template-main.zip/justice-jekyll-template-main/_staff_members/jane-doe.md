---
name: Jane Doe
image: "//placekitten.com/440/440?a=.png"
credentials: LLB
phone_extension: "02"
---

Jane has 19 years of experience in law, and specialises in property and business.